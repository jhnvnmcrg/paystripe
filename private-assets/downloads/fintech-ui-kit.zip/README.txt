Fintech UI Kit (Stripe Lab sample)

This file stands in for a real UI kit. You received it through a signed, expiring download link.
