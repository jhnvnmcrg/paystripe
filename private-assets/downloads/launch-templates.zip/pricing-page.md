# Pricing

| Plan | Price | For |
|---|---|---|
| Starter | $9/mo | Trying it out |
| Pro | $29/mo | Growing teams |
