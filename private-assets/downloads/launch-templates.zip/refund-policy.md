# Refund policy

Ask within 14 days of buying for a full refund. Refunded licenses and downloads stop working.
